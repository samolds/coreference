cd data/scorer && python new-coref-scorer.py responselist.txt ../dev/
